package com.nwdxlgzs.utils.xml.export;

import com.nwdxlgzs.utils.xml.AXmlResourceParser;
import com.nwdxlgzs.utils.xml.*;
import java.io.*;
import android.content.Context;
import com.nwdxlgzs.utils.xml.export.XMLparser;
import org.xmlpull.v1.XmlPullParserException;
import java.util.ArrayList;
public class AXMLparser {
	public AXMLparser() {
	}

	public boolean parse(String in,String out)throws IOException {
	String s= new AXmlResourceParser().decode(in, out);
	FileOutputStream fileOutputStream = new FileOutputStream(out);
	fileOutputStream.write(s.getBytes());
	fileOutputStream.close();
	return true;
	}

	public boolean parseWithFix(Context context,String in,String out)throws IOException, XmlPullParserException {
	Boolean isOK=parse(in, out);
	if (isOK) {
    //回编译成正确形式
	byte[] b = new Encoder().encodeFile(context, out);
	InputStream is = new ByteArrayInputStream(b);
	AXmlDecoder axml= AXmlDecoder.decode(is);
	ArrayList<String> list = new ArrayList<>(axml.mTableStrings.getSize());
	axml.mTableStrings.getStrings(list);
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	axml.write(list, baos);
	byte[] manifestData=baos.toByteArray();
	//将正确的回编译重新读取进行反编译
	InputStream nis = new ByteArrayInputStream(manifestData);
	String s= new AXmlResourceParser().decodeStream(nis);
	FileOutputStream fileOutputStream = new FileOutputStream(out);
	fileOutputStream.write(s.getBytes());
	fileOutputStream.close();
	return true;
	} else {
	return false;
	}
	}

	public String parse(String in)throws IOException {
	return new AXmlResourceParser().decode(in);
	}

	public String parseWithFix(Context context,String in)throws IOException, XmlPullParserException {
	String xml= parse(in);
	//重新回编译
	byte[] b= new Encoder().encodeString(context, xml);
	InputStream is = new ByteArrayInputStream(b);
	AXmlDecoder axml= AXmlDecoder.decode(is);
	ArrayList<String> list = new ArrayList<>(axml.mTableStrings.getSize());
	axml.mTableStrings.getStrings(list);
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	axml.write(list, baos);
	byte[] manifestData=baos.toByteArray();
	//将正确的回编译重新读取进行反编译
	InputStream nis = new ByteArrayInputStream(manifestData);
	return new AXmlResourceParser().decodeStream(nis);
	}

}
