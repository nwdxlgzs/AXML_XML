package com.nwdxlgzs.utils.xml;

public class mXMLformatter
{
	public mXMLformatter(){
	}
	public String format(String data) {
		return data.replaceAll("\n\\s+>",">");
		/*
		String data2=data.replaceAll("\n\\s+>",">");
		String data3=data2.replaceAll(">\n\\s+</action>"," />");
		String data4=data3.replaceAll(">\n\\s+</category>"," />");
		String data5=data4.replaceAll(">\n\\s+</data>"," />");
		String data6=data5.replaceAll("<uses-permission\n\\s+android:","<uses-permission android:");
		String data7=data6.replaceAll(">\n\\s+</uses-permission>"," />");
		String data8=data7.replaceAll(">\n\\s+</uses-sdk>"," />");
		String data9=data8.replaceAll(">\n\\s+</meta-data>"," />");
        String data10=data9.replaceAll(">\n\\s+</uses-feature>"," />");
		String data11=data10.replaceAll(">\n\\s+</uses-library>"," />");
		String data12=data11.replaceAll(">\n\\s+</protected-broadcast>"," />");
		String data13=data12.replaceAll(">\n\\s+</permission>"," />");
		
		return data13;/**/
	}
}
