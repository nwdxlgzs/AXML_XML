package com.nwdxlgzs.utils.xml.export;
import com.nwdxlgzs.utils.xml.AXmlDecoder;
import com.nwdxlgzs.utils.xml.ZInput;
import com.nwdxlgzs.utils.xml.Encoder;
import com.nwdxlgzs.utils.xml.*;
import java.io.*;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;
import java.util.ArrayList;

public class XMLparser {
	public XMLparser() {
	}

	public boolean parseString(Context context,String in,String out)throws IOException, XmlPullParserException, XmlPullParserException {
	byte[] s= new Encoder().encodeString(context, in);//new Encoder().encodeFile(context,in);
	FileOutputStream fileOutputStream = new FileOutputStream(out);
	fileOutputStream.write(s);
	fileOutputStream.close();
	return true;
	}
	
	public boolean parseStringWithReSet(Context context,String in,String out)throws IOException, XmlPullParserException, XmlPullParserException {
	Boolean isOK=parseString(context, in , out);//new Encoder().encodeFile(context,in);
	return (isOK && reparseFUN(out));//true;
	}
	
	public boolean parse(Context context,String in,String out)throws IOException, XmlPullParserException, XmlPullParserException {
	byte[] s= parse(context, in);//new Encoder().encodeFile(context,in);
	FileOutputStream fileOutputStream = new FileOutputStream(out);
	fileOutputStream.write(s);
	fileOutputStream.close();
	return true;
	}
	
	public boolean parseWithReSet(Context context,String in,String out)throws IOException, XmlPullParserException, XmlPullParserException {
    Boolean isOK=parse(context, in ,out);//new Encoder().encodeFile(context,in);
	return (isOK && reparseFUN(out));//true;
	}
	
	public byte[] parse(Context context,String in)throws IOException, XmlPullParserException {
	return new Encoder().encodeFile(context, in);
	}

    //重新解析使用正确的方式回编译，目测这一步不是太重要。
	public boolean reparseFUN(String out) throws IOException {
	InputStream is=new FileInputStream(out);
	ZInput zi=new ZInput(is);
	AXmlDecoder axml=new AXmlDecoder(zi).decode(is);
	ArrayList<String> list = new ArrayList<>(axml.mTableStrings.getSize());
	axml.mTableStrings.getStrings(list);
	ByteArrayOutputStream baos = new ByteArrayOutputStream();
	axml.write(list, baos);
	byte[] manifestData=baos.toByteArray();
	FileOutputStream fileOutputStream = new FileOutputStream(out);
	fileOutputStream.write(manifestData);
	fileOutputStream.close();
	return true;
	}
}
