package com.nwdxlgzs.utils.xml.export;

import com.nwdxlgzs.utils.xml.Encoder;
import com.nwdxlgzs.utils.xml.*;
import java.io.*;
import org.xmlpull.v1.XmlPullParserException;

import android.content.Context;

public class XMLparser{
	public XMLparser(){
	}
	public boolean parse(Context context,String in,String out)throws IOException, XmlPullParserException, XmlPullParserException {
		byte[] s= new Encoder().encodeFile(context,in);
		FileOutputStream fileOutputStream = new FileOutputStream(out);
        fileOutputStream.write(s);
        fileOutputStream.close();
		return true;
	}
	public byte[] parse(Context context,String in)throws IOException, XmlPullParserException {
		return new Encoder().encodeFile(context,in);
	}
}
