package com.nwdxlgzs.utils.xml.export;

import com.nwdxlgzs.utils.xml.AXmlResourceParser;
import com.nwdxlgzs.utils.xml.*;
import java.io.*;

public class AXMLparser{
	public AXMLparser(){
	}
	public boolean parse(String in,String out)throws IOException {
		String s= new AXmlResourceParser().decode(in,out);
		FileOutputStream fileOutputStream = new FileOutputStream(out);
        fileOutputStream.write(s.getBytes());
        fileOutputStream.close();
		return true;
	}
	public String parse(String in)throws IOException {
		return new AXmlResourceParser().decode(in);
	}
}
