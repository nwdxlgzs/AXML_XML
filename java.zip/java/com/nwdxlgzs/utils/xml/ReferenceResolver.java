package com.nwdxlgzs.utils.xml;

import com.nwdxlgzs.utils.xml.chunks.AttrChunk;
import com.nwdxlgzs.utils.xml.chunks.ValueChunk;

/**
 * Created by Roy on 15-10-5.
 */
public interface ReferenceResolver {
    int resolve(ValueChunk value, String ref);
}
